package metodosDeAcessoParaData;import java.time.LocalDate;

public interface FormataDataEmSignos {
	
	public String formataSignos(LocalDate localDate);
}

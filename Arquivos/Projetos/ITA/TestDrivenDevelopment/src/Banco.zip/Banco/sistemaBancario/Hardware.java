package Banco.sistemaBancario;

public interface Hardware {
	public String pegarNumeroDacontaCartao();
	
	public void entregarDinheiro();
	
	public void lerEnvelope();
}

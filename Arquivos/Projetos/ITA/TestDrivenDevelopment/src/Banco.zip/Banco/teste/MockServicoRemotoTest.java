package Banco.teste;

import static org.junit.Assert.*;

import org.junit.Test;

public class MockServicoRemotoTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
